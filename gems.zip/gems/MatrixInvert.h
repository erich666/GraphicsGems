#pragma once

double det4x4(Matrix4* m);
void inverse(Matrix4* in, Matrix4* out);
