#pragma once

#include "solve.h"

void sbisect(int np, poly* sseq, double min, double max, int atmin, int atmax, double* roots);
