
/* 
 * file box.h
 *	a short include file is better then no include file
 */
typedef	struct	{		/* guess what this is		*/
	long	_lowx;
	long	_lowy;
	long	_highx;
	long	_highy;
} BOX;

 
