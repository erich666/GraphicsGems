/**** Body.h ****/
#ifndef _H_Body
#define _H_Body
//#include <gl/gl.h>
typedef float Matrix[4][4];
void drawbody(Matrix Rot);
#endif
