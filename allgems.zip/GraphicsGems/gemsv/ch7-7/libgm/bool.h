// bool.h - boolean type
//
// libgm++: Graphics Math Library
// Ferdi Scheepers and Stephen F May
// 15 June 1994

#ifndef BOOL_H
#define BOOL_H

typedef int bool;
enum { false, true };

#endif
